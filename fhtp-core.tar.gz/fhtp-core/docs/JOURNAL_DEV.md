# Journal de developpement -- FHTP Core

En miroir des journaux de versions de `FHTP-ARC-001_Architecture_Technique.md`
et `FHTP-KNO-001_Knowledge_Book.md`. Chaque entree renvoie a la section du
document maitre qu'elle implemente.

| Date | Changements |
|---|---|
| 25 aout 2026 | Premier squelette du projet. Structure de dossiers (`models/`, `rules/`, `engine/`, `connectors/`, `api/`). Modele de donnees consolide implemente en Pydantic (section 6) : `Beneficiaire`, `Prescripteur`, `FormationSanitaire`, `ContratPayeur`, `Dossier` (+ `ActeRealise`, `MedicamentPrescrit`), `ExclusionContrat` (ADR-012/R8), `PECEntentePrealable`, `ConsentementPatient`, `ContestationRecours`, `LogAudit`, et les entites operationnelles des addenda fusionnes (`CleLicence`, `ReferentielLibelle`, `LotSoumission`, `ProfilImportCentre`, `ModelePayeurSocle`, `ModeleDocumentPayeur`). Premiere brique du moteur de decision (`engine/decision.py`) implementant la logique de section 2.1, avec priorite explicite donnee a la regle de securite ADR-003 (aucun FAST_TRACK avant reevaluation en ligne pour un dossier MODE_DEGRADE) -- testee explicitement, y compris le cas d'exploitation decrit en section 7.2 (tous piliers CONFORME mais origine degradee). 16 tests, tous verts. |

## Ce qui reste a faire (prochaines etapes logiques)

- **Referentiel de regles** (`fhtp_core/rules/`) : charger les regles versionnees (section 2.1) depuis des fixtures JSON, et le moteur qui les evalue pilier par pilier pour remplir `Dossier.evaluation_piliers` -- c'est la piece manquante entre les modeles et `engine/decision.py`, qui suppose aujourd'hui que l'evaluation est deja faite.
- **Contrats de connecteurs** (`fhtp_core/connectors/`) : `IConnecteurPayeur` / `IConnecteurTerrain` (section 3.1-3.2) en interfaces Python (`Protocol` ou `ABC`), plus un connecteur simule pour les tests (section 19.5).
- **Gestionnaire de dossiers** (section 2.2) : cycle de vie SOUMIS -> EN_VALIDATION -> decision, avec le Journal de Conformite (section 2.4).
- **API** (`fhtp_core/api/`) : exposition FastAPI des points d'entree de la section 12, une fois le moteur de regles et le gestionnaire de dossiers en place -- pas avant, pour ne pas exposer une API vide.
